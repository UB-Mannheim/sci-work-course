# Test Repository for Course "Scientific Writing and Bibliographic Research" @ Uni Mannheim

[Website](http://bib.uni-mannheim.de/en/cs-course/)

* Fork this repository
* Clone it to your computer
* Find the file with your number in `data/birth-dates/`
* Fill in the birth date for this computer pioneer
* `git add`
* `git commit`
* `git push`
* Send a pull request
