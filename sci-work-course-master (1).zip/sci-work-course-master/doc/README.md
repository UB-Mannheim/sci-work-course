Documentation on LaTeX
======================

## Platform-specific Installation Guides for LaTeX/Editor

* [Windows Vista, 7, 8, 10](./install-windows.md)
* [Mac OS X](./install-macosx.md)
* [Linux (Ubuntu, Debian)](./install-linux.md)

## Frequently Asked Questions

See [FAQ](faq.md).
